model = """# Simple model to illustrate the effect of delays

# Reactions
R1:
    X > Y
    k1*X


# InitPar
k1 = 0.5

# InitVar
X = 20
Y = 0
"""
