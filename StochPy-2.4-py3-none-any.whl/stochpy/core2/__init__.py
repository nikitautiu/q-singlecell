#! /usr/bin/env python
"""
StochPy - Stochastic Modeling in Python (http://stochpy.sourceforge.net)

Copyright (C) 2010-2014 T.R Maarlveld, B.G. Olivier F.J. Bruggeman all rights reserved.

Timo R. Maarleveld (tmd200@users.sourceforge.net)
VU University, Amsterdam, Netherlands

Permission to use, modify, and distribute this software is given under the
terms of the StochPy (BSD style) license. 

NO WARRANTY IS EXPRESSED OR IMPLIED.  USE AT YOUR OWN RISK.
"""
